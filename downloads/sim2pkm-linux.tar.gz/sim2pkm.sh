cd sim2pkm
python gui.py
